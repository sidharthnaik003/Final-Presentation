const NoPage = () => {
    return ( 
        <h1>
            404 ERROR
        </h1> );
}
 
export default NoPage;